import {connect} from "react-redux";
import Show from "./show";
let mapStateToProps = state=> {
    return {

    }
}


let mapDispatchToProps = dispatch=> {
    return {

    }
}


let PeopleHome = connect(mapStateToProps, mapDispatchToProps)(Show);

export default PeopleHome;