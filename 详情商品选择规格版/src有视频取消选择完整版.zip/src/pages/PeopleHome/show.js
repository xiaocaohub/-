import React from "react";
import Header from "../../components/People/Header";
import "./index.css";
class Show extends React.Component {
    render () {
        return (

            <div className="people_con">
            
                <Header></Header>
                people home
            </div>
        )
    }
}

export default Show;