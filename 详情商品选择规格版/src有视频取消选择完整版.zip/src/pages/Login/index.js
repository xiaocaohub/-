 import {connect} from "react-redux";
 import Show from "./show";
 var mapStateToProps = state=> {
    
    return {

    }
 }


 var mapDispatchToProps = dispatch=> {

    return {

    }
 }

 const Login = connect(mapStateToProps, mapDispatchToProps)(Show);

 export default Login;