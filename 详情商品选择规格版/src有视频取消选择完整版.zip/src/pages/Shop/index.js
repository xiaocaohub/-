import {connect} from "react-redux";
import Show from "./show";
let mapStateToProps = state=> {
    return {

    }
}

let mapDispatchToProps = dispatch=> {
    return {

    }
}

let Shop = connect(mapStateToProps, mapDispatchToProps)(Show);

export default Shop;