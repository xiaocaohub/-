import {connect} from "react-redux";
import Show from "./show";
var mapStateToProps = state=> {
   
   return {

   }
}


var mapDispatchToProps = dispatch=> {

   return {

   }
}

const Register = connect(mapStateToProps, mapDispatchToProps)(Show);

export default Register;