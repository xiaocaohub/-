import {connect} from "react-redux";
import Show from "./show.js";
let mapStateToProps = state=> {
    return {

    }
}


let mapDispatchToProps = dispatch=> {
    return {

    }
}


let Pay = connect(mapStateToProps, mapDispatchToProps)(Show);

export default Pay;