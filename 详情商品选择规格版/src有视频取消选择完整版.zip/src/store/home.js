let defaultState = {
    homeCount: 1
}

function homeReducer (state= defaultState, action) {
 
    return state;
}
export default homeReducer;