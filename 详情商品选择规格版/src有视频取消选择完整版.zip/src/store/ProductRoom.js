let defaultState = {

}

function productRoomReducer (state=defaultState, action) {
       return state;
}

export default productRoomReducer;