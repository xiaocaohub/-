import {SET_USER_INFO} from "../actionType/common";
export const setUserInfoAction = (value)=> ({
    type: SET_USER_INFO,
    
    payload: value
})
