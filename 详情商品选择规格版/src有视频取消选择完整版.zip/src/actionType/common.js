/** cart */
export const SET_USER_INFO = "set_user_info";


export const CHECK_SUPPLY_PRICE = "check_supply_price" ;

export const SWITCH_SUPPLY_PRICE = "switch_supply_price";