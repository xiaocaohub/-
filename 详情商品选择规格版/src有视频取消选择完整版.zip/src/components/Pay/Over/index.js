import React from "react";
import {Row, Col} from "antd";
class PayOver extends React.Component {
    render () {
        return (

            <div>
                 
            </div>
        )
    }
}

export default PayOver;